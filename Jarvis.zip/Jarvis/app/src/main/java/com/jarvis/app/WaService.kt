package com.jarvis.app
import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.glance.appwidget.updateAll
import kotlinx.coroutines.*

const val WA_CLONE = "com.whatsapp.w4b" // WhatsApp Business (or your clone's package)

/** Reads every notification, rings you when something important arrives, and talks to you via the WhatsApp clone. */
class WaService : NotificationListenerService() {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val n = sbn.notification
        val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        if (sbn.packageName == WA_CLONE) { // your messages to Jarvis = notes/tasks/events
            val a = n.actions?.firstOrNull { it.remoteInputs?.isNotEmpty() == true } ?: return
            action = a; appCtx = applicationContext
            if (text.isBlank()) return
            scope.launch {
                val items = Brain(applicationContext).classify(text)
                items.forEach { Db.get(applicationContext).dao().add(it) }
                send(Prefs.get(applicationContext, "noted") + " " + items.joinToString { "${it.type} - ${it.title}" })
                JarvisWidget().updateAll(applicationContext)
            }
            return
        }
        if (sbn.packageName == packageName || sbn.isOngoing || (n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if (title.isBlank() && text.isBlank()) return
        val app = runCatching { packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString() }.getOrDefault(sbn.packageName)
        val notif = Notif(sbn.packageName, app, title, text, System.currentTimeMillis())
        Notifs.add(this, notif); Triage.enqueue(this, notif)
    }
    companion object {
        @Volatile var action: Notification.Action? = null
        @Volatile var appCtx: Context? = null
        fun send(text: String): Boolean {
            val a = action ?: return false
            val ri = a.remoteInputs[0]; val b = Bundle().apply { putCharSequence(ri.resultKey, text) }
            val i = Intent(); RemoteInput.addResultsToIntent(a.remoteInputs, i, b)
            return runCatching { a.actionIntent.send(appCtx, 0, i); true }.getOrDefault(false)
        }
    }
}
