package com.jarvis.app
import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.glance.appwidget.updateAll
import kotlinx.coroutines.*

const val WA_CLONE = "com.whatsapp.w4b" // WhatsApp Business (or your clone's package)

/** Reads replies you send to Jarvis' number and lets the app message you back via inline reply. */
class WaService : NotificationListenerService() {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != WA_CLONE) return
        val a = sbn.notification.actions?.firstOrNull { it.remoteInputs?.isNotEmpty() == true } ?: return
        action = a; appCtx = applicationContext
        val text = sbn.notification.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
        scope.launch { // your WhatsApp message = a command/note for Jarvis
            val items = Brain(applicationContext).classify(text)
            items.forEach { Db.get(applicationContext).dao().add(it) }
            send("Noted, sir: " + items.joinToString { "${it.type} - ${it.title}" })
            JarvisWidget().updateAll(applicationContext)
        }
    }
    companion object {
        @Volatile var action: Notification.Action? = null
        @Volatile var appCtx: Context? = null
        fun sendFrom(ctx: Context, text: String): Boolean = send(text)
        fun send(text: String): Boolean {
            val a = action ?: return false
            val ri = a.remoteInputs[0]; val b = Bundle().apply { putCharSequence(ri.resultKey, text) }
            val i = Intent(); RemoteInput.addResultsToIntent(a.remoteInputs, i, b)
            return runCatching { a.actionIntent.send(appCtx, 0, i); true }.getOrDefault(false)
        }
    }
}
