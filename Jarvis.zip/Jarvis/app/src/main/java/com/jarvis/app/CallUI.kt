package com.jarvis.app
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

val Gold = Color(0xFFFFB300); val GoldL = Color(0xFFFFD54F); val GoldD = Color(0xFFFF8F00)
private class Frag(val r: Float, val a: Float, val s: Float, val w: Float, val h: Float, val al: Float, val ring: Int)
private val frags = java.util.Random(7).let { rnd -> List(280) {
    Frag(0.12f + rnd.nextFloat() * 0.88f, rnd.nextFloat() * 360f, (rnd.nextFloat() - 0.5f) * 2f, 2f + rnd.nextFloat() * 11f, 1.5f + rnd.nextFloat() * 3f, 0.25f + rnd.nextFloat() * 0.75f, rnd.nextInt(3)) } }

/** Golden holographic code-sphere, like the Jarvis hologram. Pulses harder while he talks. */
@Composable fun JarvisOrb(active: Boolean, modifier: Modifier = Modifier) {
    val tr = rememberInfiniteTransition(label = "orb")
    val t by tr.animateFloat(0f, 360f, infiniteRepeatable(tween(30000, easing = LinearEasing)), label = "t")
    val pulse by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(if (active) 700 else 1600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p")
    Canvas(modifier) {
        val c = center; val R = size.minDimension / 2 * (0.94f + (if (active) 0.06f else 0.02f) * pulse)
        drawCircle(Brush.radialGradient(listOf(Gold.copy(alpha = 0.35f + 0.25f * pulse), Color.Transparent), c, R * 0.55f), R * 0.55f, c)
        for (k in 0 until 6) {
            val rr = R * (0.45f + k * 0.09f)
            rotate(t * (if (k % 2 == 0) 1f else -1.4f) * (1 + k * 0.15f), c) {
                drawArc(if (k % 2 == 0) Gold else GoldL, 20f * k, 70f + 25f * k, false, Offset(c.x - rr, c.y - rr), Size(rr * 2, rr * 2), alpha = 0.55f, style = Stroke(width = 1.5f + k * 0.5f)) }
        }
        for (f in frags) {
            val ang = Math.toRadians((f.a + t * f.s * (1f + f.ring * 0.4f)).toDouble())
            val x = c.x + (cos(ang) * f.r * R).toFloat(); val y = c.y + (sin(ang) * f.r * R * 0.92f).toFloat()
            val col = if (f.ring == 0) Gold else if (f.ring == 1) GoldL else GoldD
            rotate(Math.toDegrees(ang).toFloat() + 90f, Offset(x, y)) {
                drawRect(col.copy(alpha = f.al * 0.35f), Offset(x - f.w, y - f.h), Size(f.w * 2, f.h * 2))
                drawRect(col.copy(alpha = f.al), Offset(x - f.w / 2, y - f.h / 2), Size(f.w, f.h)) }
        }
        drawCircle(Color(0xFFFFE082), R * 0.06f * (1f + 0.4f * pulse), c)
    }
}

class JarvisCallActivity : ComponentActivity() {
    private var voice: Voice? = null
    override fun onCreate(s: Bundle?) {
        super.onCreate(s); setShowWhenLocked(true); setTurnScreenOn(true)
        val say = intent.getStringExtra("say") ?: ""
        setContent {
            MaterialTheme(darkColorScheme(primary = Gold, background = Color(0xFF05080F), surface = Color(0xFF05080F))) {
                var st by remember { mutableStateOf("ring") }
                Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF05080F), Color(0xFF0B1628)))).padding(24.dp),
                    Arrangement.SpaceBetween, Alignment.CenterHorizontally) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(top = 56.dp)) {
                        Text("J.A.R.V.I.S.", fontSize = 30.sp, letterSpacing = 8.sp, color = Gold, fontFamily = FontFamily.Monospace)
                        Text(when (st) { "ring" -> "INCOMING CALL"; "talk" -> "ON CALL"; else -> "CALL ENDED" }, fontSize = 13.sp, letterSpacing = 4.sp, color = GoldL.copy(alpha = 0.8f), fontFamily = FontFamily.Monospace)
                    }
                    JarvisOrb(active = st == "talk", modifier = Modifier.size(320.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(bottom = 48.dp)) {
                        if (st == "talk") Text(say, textAlign = TextAlign.Center, color = GoldL, fontFamily = FontFamily.Monospace, fontSize = 14.sp, modifier = Modifier.padding(bottom = 16.dp))
                        if (st == "ring") Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                            Button({ FakeCall.stop(this@JarvisCallActivity); finish() }, shape = RoundedCornerShape(50), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB71C1C), contentColor = Color.White),
                                modifier = Modifier.height(60.dp).width(130.dp)) { Text("Decline") }
                            Button({
                                st = "talk"; FakeCall.stop(this@JarvisCallActivity)
                                val v = Voice(this@JarvisCallActivity).also { voice = it }
                                v.speak(say) { st = "end"; window.decorView.postDelayed({ finish() }, 1500) }
                            }, shape = RoundedCornerShape(50), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF05080F)),
                                modifier = Modifier.height(60.dp).width(130.dp)) { Text("Answer") }
                        }
                    }
                }
            }
        }
    }
    override fun onDestroy() { voice?.shutdown(); FakeCall.stop(this); super.onDestroy() }
}
