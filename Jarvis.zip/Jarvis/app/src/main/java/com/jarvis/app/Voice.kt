package com.jarvis.app
import android.content.Context
import android.content.Intent
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.os.Bundle
import java.util.Locale

class Voice(ctx: Context) {
    private var tts: TextToSpeech? = null
    init { tts = TextToSpeech(ctx) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale.UK } }
    private val stt = SpeechRecognizer.createSpeechRecognizer(ctx)
    private val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)

    fun speak(s: String) { tts?.setPitch(0.8f); tts?.speak(s, TextToSpeech.QUEUE_FLUSH, null, "j") }
    fun listen(onText: (String) -> Unit) {
        stt.setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle) { r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(onText) }
            override fun onReadyForSpeech(p: Bundle?) {} override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {} override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {} override fun onError(e: Int) {}
            override fun onPartialResults(p: Bundle?) {} override fun onEvent(t: Int, p: Bundle?) {}
        })
        stt.startListening(intent)
    }
}
