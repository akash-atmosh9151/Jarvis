package com.jarvis.app
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class Voice(private val ctx: Context) {
    private val kokoro = KokoroTts(ctx)
    private val main = Handler(Looper.getMainLooper())
    private val prefs = ctx.getSharedPreferences("voice", Context.MODE_PRIVATE)
    private var tts: TextToSpeech? = null
    private var done: (() -> Unit)? = null
    @Volatile private var ready = false
    private var pending: (() -> Unit)? = null
    private val stt = SpeechRecognizer.createSpeechRecognizer(ctx)
    private val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2000)
    private val male = listOf("gbd", "gbb", "rjs") // Google en-GB male voice codes

    init {
        tts = TextToSpeech(ctx) { if (it == TextToSpeech.SUCCESS) {
            tts?.language = Locale.UK
            ready = true; pending?.let { main.post(it); pending = null }
            tts?.setAudioAttributes(android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_MEDIA).setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH).build())
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { fire() }
                override fun onError(id: String?) { fire() }
            }) } }
    }
    private fun fire() { val d = done; done = null; if (d != null) main.post(d) }

    fun britishVoices() = tts?.voices.orEmpty()
        .filter { it.locale.language == "en" && it.locale.country == "GB" }
        .sortedBy { v -> (if (male.any { v.name.contains(it) }) 0 else 2) + (if (v.isNetworkConnectionRequired) 1 else 0) }
    private fun current() = britishVoices().let { l -> l.firstOrNull { it.name == prefs.getString("v", null) } ?: l.firstOrNull() }
    fun nextVoice(): String {
        val l = britishVoices(); if (l.isEmpty()) return "none found"
        val i = l.indexOfFirst { it.name == current()?.name }
        val n = l[(i + 1) % l.size]; prefs.edit().putString("v", n.name).apply(); return n.name
    }
    fun speak(s: String, then: (() -> Unit)? = null) {
        if (KokoroTts.ready(ctx)) { kokoro.speak(s) { then?.let { main.post(it) } }; return }
        if (!ready) { pending = { speak(s, then) }; Status.add("Voice engine starting..."); return }
        current()?.let { tts?.voice = it }; tts?.setPitch(0.85f); tts?.setSpeechRate(0.95f)
        done = then; val r = tts?.speak(s, TextToSpeech.QUEUE_FLUSH, null, "j")
        Status.add("TTS speak result: $r (0 = ok)")
        if (r != TextToSpeech.SUCCESS) { done = null; then?.let { main.post(it) } }
    }
    fun listen(onFail: () -> Unit = {}, onText: (String) -> Unit) {
        stt.setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle) {
                val t = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                Status.add("Heard: $t"); if (t.isNullOrBlank()) onFail() else onText(t) }
            override fun onError(e: Int) { Status.add("Mic error code $e (7=no speech heard, 9=no permission)"); onFail() }
            override fun onReadyForSpeech(p: Bundle?) {} override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {} override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {} override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        stt.startListening(intent)
    }
    fun stop() { done = null; kokoro.stop(); tts?.stop(); stt.cancel() }
    fun shutdown() { stop(); tts?.shutdown(); stt.destroy() }
}
