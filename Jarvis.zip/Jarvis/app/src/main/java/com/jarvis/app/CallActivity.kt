package com.jarvis.app
import android.os.Bundle
import android.telecom.Call
import android.telecom.CallAudioState
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

class CallActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s); setShowWhenLocked(true); setTurnScreenOn(true)
        setContent {
            MaterialTheme(darkColorScheme(primary = Color(0xFFFFB300), background = Color(0xFF0B0F1A), surface = Color(0xFF0B0F1A))) {
                val st by Calls.state.collectAsState(); val c = Calls.current
                LaunchedEffect(st, c) { if (c == null || st == Call.STATE_DISCONNECTED) finish() }
                Surface(Modifier.fillMaxSize()) {
                    Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
                        Text(c?.details?.handle?.schemeSpecificPart ?: "Unknown", style = MaterialTheme.typography.headlineMedium)
                        Text(when (st) { Call.STATE_RINGING -> "Incoming call"; Call.STATE_DIALING, Call.STATE_CONNECTING -> "Calling..."; Call.STATE_ACTIVE -> "On call"; else -> "" })
                        Spacer(Modifier.height(32.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            if (st == Call.STATE_RINGING) Button({ c?.answer(0) }) { Text("Answer") }
                            Button({ if (st == Call.STATE_RINGING) c?.reject(false, null) else c?.disconnect() }) { Text(if (st == Call.STATE_RINGING) "Decline" else "End") }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            TextButton({ Calls.service?.setAudioRoute(CallAudioState.ROUTE_SPEAKER) }) { Text("Speaker") }
                            TextButton({ Calls.service?.setAudioRoute(CallAudioState.ROUTE_EARPIECE) }) { Text("Earpiece") }
                        }
                    }
                }
            }
        }
    }
}
