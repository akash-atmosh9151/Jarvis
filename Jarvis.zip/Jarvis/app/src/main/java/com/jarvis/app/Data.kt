package com.jarvis.app
import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity data class Item(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,            // note | task | event
    val title: String,
    val whenMs: Long? = null,    // events only
    val status: String = "new",  // new | confirmed | done
    val created: Long = System.currentTimeMillis())

@Dao interface ItemDao {
    @Query("SELECT * FROM Item ORDER BY created DESC") fun all(): Flow<List<Item>>
    @Insert suspend fun add(i: Item): Long
    @Update suspend fun update(i: Item)
}

@Database(entities = [Item::class], version = 1, exportSchema = false) abstract class Db : RoomDatabase() {
    abstract fun dao(): ItemDao
    companion object {
        @Volatile private var I: Db? = null
        fun get(c: Context): Db = I ?: synchronized(this) {
            Room.databaseBuilder(c.applicationContext, Db::class.java, "jarvis.db").build().also { I = it } }
    }
}
