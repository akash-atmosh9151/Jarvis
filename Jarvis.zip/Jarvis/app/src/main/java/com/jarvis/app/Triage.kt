package com.jarvis.app
import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject

/** Batches notifications, has the AI rate them (0 spam .. 3 urgent) and summarise them, and calls you only for urgent ones. */
object Triage {
    private val pending = mutableListOf<Notif>()
    private val h = Handler(Looper.getMainLooper())
    private var scheduled = false
    private const val URGENT_GAP_MS = 10 * 60_000L // at most one urgent call per 10 minutes

    @Synchronized fun enqueue(c: Context, n: Notif) {
        pending += n
        if (!scheduled) { scheduled = true; h.postDelayed({ Thread { process(c) }.start() }, 25_000) }
    }
    private fun clean(s: String) = s.replace(Regex("\\d{4,}"), "#").take(200) // mask long numbers (OTPs, accounts)

    private fun prompt(c: Context, b: List<Notif>): String {
        val apps = Prefs.importantApps(c).joinToString { p -> runCatching { c.packageManager.getApplicationLabel(c.packageManager.getApplicationInfo(p, 0)).toString() }.getOrDefault(p) }
        return """You triage phone notifications. The user marked these apps important: [$apps]. Important keywords: [${Prefs.keywords(c)}].
Rate each notification p: 0 = spam, promo or noise; 1 = routine; 2 = worth mentioning in the next briefing; 3 = urgent, needs the user's attention right now (emergencies, time-sensitive requests from real people, security alerts, delivery at the door). Be strict: most are 0 or 1. Give each a summary s of at most 12 words.
Also give "call": one natural spoken sentence (max 25 words) telling the user about the urgent ones, or "" if none.
Reply ONLY with JSON: {"items":[{"i":1,"p":1,"s":"..."}],"call":"..."}
Notifications:
""" + b.mapIndexed { i, n -> "${i + 1}. [${n.app}] ${clean(n.title)}: ${clean(n.text)}" }.joinToString("\n")
    }

    private fun process(c: Context) {
        val batch: List<Notif>
        synchronized(this) { batch = pending.toList(); pending.clear(); scheduled = false }
        if (batch.isEmpty()) return
        val rated = HashMap<Long, Pair<Int, String>>(); var call = ""
        val answer = if (Ai.enabled(c)) Ai.ask(c, prompt(c, batch)) else null
        if (answer != null) runCatching {
            val j = JSONObject(answer.substring(answer.indexOf('{'), answer.lastIndexOf('}') + 1))
            val arr = j.getJSONArray("items")
            for (k in 0 until arr.length()) { val o = arr.getJSONObject(k); val idx = o.getInt("i") - 1
                if (idx in batch.indices) rated[batch[idx].time] = o.getInt("p") to o.optString("s", batch[idx].title) }
            call = j.optString("call", "")
        }.onFailure { Status.add("AI reply unreadable: ${it.message}") }
        if (rated.isEmpty()) { // no AI: marked app or keyword = urgent, everything else routine
            val apps = Prefs.importantApps(c); val kw = Prefs.keywords(c).split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
            batch.forEach { n -> val hit = n.pkg in apps || kw.any { "${n.title} ${n.text}".lowercase().contains(it) }
                rated[n.time] = (if (hit) 3 else 1) to n.title.ifBlank { n.text }.take(80) }
        }
        Notifs.rate(c, rated)
        val urgent = batch.filter { (rated[it.time]?.first ?: 0) >= 3 }
        if (urgent.isEmpty() || System.currentTimeMillis() - Prefs.lastUrgent(c) < URGENT_GAP_MS) return // too soon: goes into the next briefing
        Prefs.setUrgent(c, System.currentTimeMillis())
        if (call.isBlank()) call = if (urgent.size == 1) Prefs.get(c, "important").replace("%app%", urgent[0].app).replace("%title%", urgent[0].title).replace("%text%", urgent[0].text)
            else "Sir, ${urgent.size} important alerts. " + urgent.joinToString(". ") { rated[it.time]!!.second }
        FakeCall.ring(c, call)
    }
}
