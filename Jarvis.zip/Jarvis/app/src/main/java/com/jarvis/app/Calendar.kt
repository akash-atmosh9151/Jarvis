package com.jarvis.app
import android.content.ContentValues
import android.content.Context
import android.provider.CalendarContract.*
import java.util.TimeZone

/** Call ONLY after the user taps Confirm. */
fun addToCalendar(c: Context, i: Item): Boolean = runCatching {
    val cal = c.contentResolver.query(Calendars.CONTENT_URI, arrayOf(Calendars._ID), "${Calendars.VISIBLE}=1", null, null)
        ?.use { if (it.moveToFirst()) it.getLong(0) else null } ?: return@runCatching false
    val start = i.whenMs ?: (System.currentTimeMillis() + 3_600_000)
    c.contentResolver.insert(Events.CONTENT_URI, ContentValues().apply {
        put(Events.CALENDAR_ID, cal); put(Events.TITLE, i.title)
        put(Events.DTSTART, start); put(Events.DTEND, start + 3_600_000)
        put(Events.EVENT_TIMEZONE, TimeZone.getDefault().id) }) != null
}.getOrDefault(false)
