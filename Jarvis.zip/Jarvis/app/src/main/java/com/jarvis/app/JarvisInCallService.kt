package com.jarvis.app
import android.app.*
import android.content.Intent
import android.media.*
import android.os.Handler
import android.os.Looper
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import androidx.glance.appwidget.updateAll
import kotlinx.coroutines.*

/** Runs only when Jarvis is the default phone app. */
class JarvisInCallService : InCallService() {
    private val h = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var voice: Voice? = null
    private var jarvisCall: Call? = null
    private var tries = 0
    private val duty get() = getSharedPreferences("voice", MODE_PRIVATE).getBoolean("duty", false)

    private val cb = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) {
            Calls.state.value = state
            if (call == jarvisCall && state == Call.STATE_ACTIVE) h.postDelayed({ startDialog(call) }, 1500)
        }
    }
    override fun onCreate() { super.onCreate(); Calls.service = this }
    override fun onDestroy() { Calls.service = null; voice?.shutdown(); scope.cancel(); super.onDestroy() }

    override fun onCallAdded(call: Call) {
        if (voice == null) voice = Voice(this)
        Calls.current = call; call.registerCallback(cb); Calls.state.value = call.state
        val ringing = call.state == Call.STATE_RINGING
        Status.add("Call: ringing=$ringing, on duty=$duty")
        showUi(ringing)
        if (ringing && duty) h.postDelayed({
            if (call.state == Call.STATE_RINGING) { jarvisCall = call; call.answer(0); Status.add("Answered the call") } }, ANSWER_DELAY_MS)
    }
    override fun onCallRemoved(call: Call) {
        call.unregisterCallback(cb)
        if (call == Calls.current) Calls.current = null
        if (call == jarvisCall) { jarvisCall = null; tries = 0; voice?.stop() }
        Calls.state.value = Call.STATE_DISCONNECTED
        getSystemService(NotificationManager::class.java).cancel(2)
    }

    private fun showUi(ringing: Boolean) {
        val i = Intent(this, CallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("calls", "Calls", NotificationManager.IMPORTANCE_HIGH))
        nm.notify(2, Notification.Builder(this, "calls").setSmallIcon(android.R.drawable.sym_call_incoming)
            .setContentTitle(if (ringing) "Incoming call" else "Call in progress").setCategory(Notification.CATEGORY_CALL)
            .setContentIntent(pi).setFullScreenIntent(pi, true).setOngoing(true).build())
        runCatching { startActivity(i) }
    }

    private fun startDialog(call: Call) {
        setAudioRoute(CallAudioState.ROUTE_SPEAKER)
        val am = getSystemService(AudioManager::class.java)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) * 8 / 10, 0)
        Status.add("Speaking greeting")
        h.postDelayed({ Status.add("Audio route: ${callAudioState?.route} (8 = speaker, 1 = earpiece)") }, 1000)
        scope.launch { delay(3000)
            listOf("MIC" to MediaRecorder.AudioSource.MIC, "RECOGNITION" to MediaRecorder.AudioSource.VOICE_RECOGNITION, "COMM" to MediaRecorder.AudioSource.VOICE_COMMUNICATION)
                .forEach { (n, s) -> Status.add("Mic $n level: ${micPeak(s)}") } }
        val v = voice ?: Voice(this).also { voice = it }
        v.speak("Hello, this is Jarvis, the assistant. This call is being transcribed. Please say your name and message after I finish.") { listenTurn(call) }
    }
    @android.annotation.SuppressLint("MissingPermission")
    private fun micPeak(src: Int): Int = runCatching {
        val r = AudioRecord(src, 16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, 32000)
        val b = ShortArray(16000); r.startRecording(); var n = 0
        while (n < b.size) { val c = r.read(b, n, b.size - n); if (c <= 0) break; n += c }
        r.stop(); r.release(); (0 until n).maxOfOrNull { Math.abs(b[it].toInt()) } ?: 0
    }.getOrElse { Status.add("Mic test failed: ${it.message}"); -1 }

    private fun listenTurn(call: Call): Unit = voice!!.listen(onFail = {
        if (++tries < 3) voice?.speak("Sorry, I didn't catch that. Could you repeat?") { listenTurn(call) }
        else finish(call, "I'll let him know you called. Goodbye.")
    }) { handle(call, it) }

    private fun handle(call: Call, text: String): Job = scope.launch {
        val dao = Db.get(applicationContext).dao()
        dao.add(Item(type = "note", title = "Call: $text"))
        Brain(applicationContext).classify(text).filter { it.type != "note" }.forEach { dao.add(it) }
        JarvisWidget().updateAll(applicationContext)
        WaService.send("Call summary: $text")
        h.post { finish(call, "Thank you. I've noted that and will pass it on. Goodbye.") }
    }
    private fun finish(call: Call, line: String): Unit = voice!!.speak(line) { h.postDelayed({ call.disconnect() }, 500) }
}
