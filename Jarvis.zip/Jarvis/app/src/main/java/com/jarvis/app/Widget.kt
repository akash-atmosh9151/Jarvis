package com.jarvis.app
import android.content.Context
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.*
import androidx.glance.appwidget.*
import androidx.glance.layout.*
import androidx.glance.text.*
import kotlinx.coroutines.flow.first

class JarvisWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val items = Db.get(context).dao().all().first().filter { it.status != "done" }.take(6)
        provideContent {
            Column(GlanceModifier.fillMaxSize().background(Color(0xFF0B0F1A)).padding(12.dp)) {
                Text("J.A.R.V.I.S.", style = TextStyle(color = ColorProvider(Color(0xFFFFB300)), fontWeight = FontWeight.Bold, fontSize = 14.sp))
                items.forEach { Text((when (it.type) { "task" -> "☐ "; "event" -> "📅 "; else -> "• " }) + it.title,
                    style = TextStyle(color = ColorProvider(Color(0xFFE8EAF0)), fontSize = 12.sp), maxLines = 1) }
            }
        }
    }
}
class JarvisReceiver : GlanceAppWidgetReceiver() { override val glanceAppWidget = JarvisWidget() }
