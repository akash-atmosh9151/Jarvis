package com.jarvis.app
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.glance.appwidget.updateAll
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable fun Home(dao: ItemDao, brain: Brain, voice: Voice) {
    val ctx = LocalContext.current; val list by dao.all().collectAsState(emptyList()); val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    fun submit(t: String) { scope.launch {
        val r = withContext(Dispatchers.IO) { brain.classify(t).onEach { dao.add(it) } }
        voice.speak(Prefs.get(ctx, "noted")); JarvisWidget().updateAll(ctx)
        WaService.send("Jarvis: " + r.joinToString { "${it.type} - ${it.title}" }) } }
    Column(Modifier.padding(16.dp)) {
        Row { OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("Tell Jarvis...") })
            Button({ if (text.isNotBlank()) { submit(text); text = "" } }, Modifier.padding(start = 8.dp)) { Text("Send") } }
        Row { Button({ voice.listen { submit(it) } }) { Text("🎤 Speak") }
            TextButton({ voice.speak(BriefingReceiver.readout(ctx)) }) { Text("Read my notifications") }
            TextButton({ voice.stop() }) { Text("Stop") } }
        LazyColumn { items(list) { i -> Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${i.type.uppercase()}  ${i.title}", Modifier.weight(1f))
                if (i.type == "event" && i.status == "new") TextButton({ scope.launch {
                    if (addToCalendar(ctx, i)) withContext(Dispatchers.IO) { dao.update(i.copy(status = "confirmed")) } } }) { Text("Confirm") }
                else if (i.type == "task" && i.status != "done") TextButton({ scope.launch(Dispatchers.IO) { dao.update(i.copy(status = "done")) } }) { Text("Done") }
            } } } }
    }
}

@Composable fun Alerts() {
    val ctx = LocalContext.current; val tick by Notifs.tick.collectAsState()
    var apps by remember { mutableStateOf(Prefs.importantApps(ctx)) }
    val list = remember(tick) { Notifs.all(ctx) }
    Column(Modifier.padding(16.dp)) {
        Text("Tap ★ to mark an app important. Jarvis will call you whenever it notifies.", style = MaterialTheme.typography.bodySmall)
        if (list.isEmpty()) Text("No notifications yet. Enable notification access in Settings.")
        LazyColumn { items(list) { n -> Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(n.app, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
                Text((if (n.p >= 3) "🔴 " else if (n.p == 2) "🟠 " else "") + n.sum.ifBlank { "${n.title} ${n.text}" }, maxLines = 2) }
            TextButton({ Prefs.toggleApp(ctx, n.pkg); apps = Prefs.importantApps(ctx) }) { Text(if (n.pkg in apps) "★" else "☆") } } } }
    }
}

@Composable fun SettingsTab(voice: Voice) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val vals = remember { mutableStateMapOf<String, String>().apply { Prefs.defaults.keys.forEach { put(it, Prefs.get(ctx, it)) } } }
    var kw by remember { mutableStateOf(Prefs.keywords(ctx)) }
    var interval by remember { mutableStateOf(Prefs.interval(ctx)) }
    var vn by remember { mutableStateOf("") }
    var key by remember { mutableStateOf(Prefs.aiKey(ctx)) }
    var prov by remember { mutableStateOf(Prefs.aiProvider(ctx)) }
    var model by remember { mutableStateOf(Prefs.aiModel(ctx)) }
    val log by Status.log.collectAsState()
    LazyColumn(Modifier.padding(16.dp)) {
        item {
            Text("Jarvis calls me every", style = MaterialTheme.typography.titleMedium)
            Row { listOf(0, 30, 60, 120, 240).forEach { m -> val sel = interval == m
                TextButton({ interval = m; Prefs.setInterval(ctx, m); BriefingReceiver.schedule(ctx) }) {
                    Text(if (m == 0) "Off" else if (m < 60) "${m}m" else "${m / 60}h", fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal, color = if (sel) MaterialTheme.colorScheme.primary else Color.Gray) } } }
            OutlinedTextField(kw, { kw = it; Prefs.setKeywords(ctx, it) }, Modifier.fillMaxWidth(), label = { Text("Important keywords, comma separated") })
            TextButton({ FakeCall.testIn5s(ctx) }) { Text("Test call in 5 seconds (lock your screen)") }
            Text("AI: summaries + priority", style = MaterialTheme.typography.titleMedium)
            Row { listOf("gemini", "claude").forEach { pv -> val sel = prov == pv
                TextButton({ prov = pv; Prefs.setAiProvider(ctx, pv); model = Prefs.aiModel(ctx) }) {
                    Text(pv.replaceFirstChar { it.uppercase() }, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal, color = if (sel) MaterialTheme.colorScheme.primary else Color.Gray) } }
                TextButton({ scope.launch(Dispatchers.IO) { Status.add("AI says: " + (Ai.ask(ctx, "Reply with the single word: ready") ?: "no reply")) } }) { Text("Test AI") } }
            OutlinedTextField(key, { key = it; Prefs.setAiKey(ctx, it) }, Modifier.fillMaxWidth(), label = { Text("API key") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
            OutlinedTextField(model, { model = it; Prefs.setAiModel(ctx, it) }, Modifier.fillMaxWidth(), label = { Text("Model") })
            Text("With a key, notification text (long numbers masked) is sent to that provider to rate and summarise it. No key = simple rules.", style = MaterialTheme.typography.bodySmall)
            Text("Responses (edit freely)", style = MaterialTheme.typography.titleMedium)
        }
        items(Prefs.defaults.keys.toList()) { k ->
            OutlinedTextField(vals[k] ?: "", { vals[k] = it; Prefs.set(ctx, k, it) }, Modifier.fillMaxWidth().padding(vertical = 4.dp), label = { Text(Prefs.labels[k] ?: k) }) }
        item {
            Button({ Prefs.reset(ctx); Prefs.defaults.forEach { (k, v) -> vals[k] = v } }) { Text("Reset responses") }
            TextButton({ vn = voice.nextVoice(); voice.speak("Good evening. Jarvis at your service.") }) { Text("Voice: " + vn.ifEmpty { "tap to change" }) }
            TextButton({ ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }) { Text("1. Enable notification access") }
            TextButton({ runCatching { ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:${ctx.packageName}"))) } }) { Text("2. Allow full-screen calls") }
            Button({ scope.launch(Dispatchers.IO) { Status.add("Downloading Jarvis voice..."); runCatching { KokoroTts.download(ctx) }
                .onSuccess { Status.add("Jarvis voice ready") }.onFailure { Status.add("Download failed: ${it.message}") } } }) {
                Text(if (KokoroTts.ready(ctx)) "Jarvis voice installed" else "Download Jarvis voice (330 MB, Wi-Fi)") }
            Text(log.takeLast(4).joinToString("\n"), style = MaterialTheme.typography.bodySmall)
        }
    }
}
