package com.jarvis.app
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.*
import android.os.*
import android.telecom.TelecomManager
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import androidx.glance.appwidget.updateAll
import kotlinx.coroutines.*

const val ANSWER_DELAY_MS = 8_000L // rings this long, then Jarvis picks up

class CallService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private lateinit var voice: Voice
    private var answered = false
    private var tries = 0
    private val answerTask = Runnable { runCatching { getSystemService(TelecomManager::class.java).acceptRingingCall(); answered = true }.onSuccess { Status.add("Answered the call") }.onFailure { Status.add("Answer failed: ${it.message}") } }

    private val cb = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
        override fun onCallStateChanged(state: Int) {
            when (state) {
                TelephonyManager.CALL_STATE_RINGING -> { Status.add("Ringing: answering in ${ANSWER_DELAY_MS / 1000}s"); h.postDelayed(answerTask, ANSWER_DELAY_MS) }
                TelephonyManager.CALL_STATE_OFFHOOK -> { h.removeCallbacks(answerTask); if (answered) h.postDelayed({ startDialog() }, 1500) }
                else -> { h.removeCallbacks(answerTask); answered = false; tries = 0; voice.stop() }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("jarvis", "Jarvis duty", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "jarvis").setContentTitle("Jarvis is on duty").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        voice = Voice(this)
        Status.add("On duty. phone-state perm=${checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE) == 0}, answer perm=${checkSelfPermission(android.Manifest.permission.ANSWER_PHONE_CALLS) == 0}")
        runCatching { getSystemService(TelephonyManager::class.java).registerTelephonyCallback(mainExecutor, cb) }.onSuccess { Status.add("Listening for calls") }.onFailure { Status.add("Call listener failed: ${it.message}") }
    }

    private fun startDialog() {
        Status.add("Speaking greeting")
        val am = getSystemService(AudioManager::class.java)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) * 8 / 10, 0)
        runCatching { am.availableCommunicationDevices.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }?.let { am.setCommunicationDevice(it) } }
        am.isSpeakerphoneOn = true
        Status.add("Speaker on: ${am.isSpeakerphoneOn}")
        scope.launch { Status.add("Mic level in call (0 = blocked): ${micPeak()}") }
        voice.speak("Hello, this is Jarvis, the assistant. This call is being transcribed. Please say your name and message after I finish.") { listenTurn() }
    }
    @android.annotation.SuppressLint("MissingPermission")
    private fun micPeak(): Int = runCatching {
        val r = AudioRecord(MediaRecorder.AudioSource.MIC, 16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, 64000)
        val b = ShortArray(64000); r.startRecording(); var n = 0; var peak = 0
        while (n < b.size) { val c = r.read(b, n, b.size - n); if (c <= 0) break; n += c }
        r.stop(); r.release(); (0 until n).maxOfOrNull { Math.abs(b[it].toInt()) } ?: 0
    }.getOrElse { Status.add("Mic test failed: ${it.message}"); -1 }
    private fun listenTurn(): Unit = voice.listen(onFail = {
        if (++tries < 3) voice.speak("Sorry, I didn't catch that. Could you repeat?") { listenTurn() }
        else finish("I'll let him know you called. Goodbye.")
    }) { handle(it) }

    private fun handle(text: String): Job = scope.launch {
        val dao = Db.get(applicationContext).dao()
        dao.add(Item(type = "note", title = "Call: $text"))
        Brain(applicationContext).classify(text).filter { it.type != "note" }.forEach { dao.add(it) }
        JarvisWidget().updateAll(applicationContext)
        WaService.send("Call summary: $text")
        h.post { finish("Thank you. I've noted that and will pass it on. Goodbye.") }
    }
    private fun finish(line: String): Unit = voice.speak(line) {
        h.postDelayed({ runCatching { getSystemService(TelecomManager::class.java).endCall() } }, 500) }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onDestroy() {
        runCatching { getSystemService(TelephonyManager::class.java).unregisterTelephonyCallback(cb) }
        voice.shutdown(); scope.cancel(); super.onDestroy()
    }
}
