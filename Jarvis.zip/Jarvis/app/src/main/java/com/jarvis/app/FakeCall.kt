package com.jarvis.app
import android.app.*
import android.content.*
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.glance.appwidget.updateAll
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

/** Jarvis "calls" you: a real-looking incoming call screen with ringtone. Answer it and he speaks. */
object FakeCall {
    private var last = 0L
    fun ring(c: Context, say: String) {
        if (System.currentTimeMillis() - last < 20_000) return; last = System.currentTimeMillis()
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jcall", "Jarvis calls", NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE), AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE).build())
            enableVibration(true); vibrationPattern = longArrayOf(0, 800, 600, 800) })
        val i = Intent(c, JarvisCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("say", say)
        val pi = PendingIntent.getActivity(c, (System.currentTimeMillis() % 100000).toInt(), i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(c, "jcall").setSmallIcon(android.R.drawable.sym_call_incoming).setContentTitle("Jarvis").setContentText("Incoming call")
            .setCategory(Notification.CATEGORY_CALL).setContentIntent(pi).setFullScreenIntent(pi, true).setOngoing(true).setTimeoutAfter(30_000).build()
        n.flags = n.flags or Notification.FLAG_INSISTENT
        nm.notify(7, n)
    }
    fun stop(c: Context) = c.getSystemService(NotificationManager::class.java).cancel(7)
    fun testIn5s(c: Context) { Handler(Looper.getMainLooper()).postDelayed({ ring(c, "Testing, sir. All systems nominal.") }, 5000) }
}

class JarvisCallActivity : ComponentActivity() {
    private var voice: Voice? = null
    override fun onCreate(s: Bundle?) {
        super.onCreate(s); setShowWhenLocked(true); setTurnScreenOn(true)
        val say = intent.getStringExtra("say") ?: ""
        setContent {
            MaterialTheme(darkColorScheme(primary = Color(0xFFFFB300), background = Color(0xFF0B0F1A), surface = Color(0xFF0B0F1A))) {
                var st by remember { mutableStateOf("ring") }
                Surface(Modifier.fillMaxSize()) {
                    Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
                        Text("J.A.R.V.I.S.", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
                        Text(when (st) { "ring" -> "Incoming call..."; "talk" -> "On call"; else -> "Call ended" })
                        Spacer(Modifier.height(40.dp))
                        if (st == "ring") Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                            Button({ FakeCall.stop(this@JarvisCallActivity); finish() }) { Text("Decline") }
                            Button({
                                st = "talk"; FakeCall.stop(this@JarvisCallActivity)
                                val v = Voice(this@JarvisCallActivity).also { voice = it }
                                v.speak(say) { st = "end"; window.decorView.postDelayed({ finish() }, 1500) }
                            }) { Text("Answer") }
                        }
                        if (st == "talk") Text(say, textAlign = TextAlign.Center)
                    }
                }
            }
        }
    }
    override fun onDestroy() { voice?.shutdown(); FakeCall.stop(this); super.onDestroy() }
}

/** Scheduled "occasional" calls + the spoken briefing. */
class BriefingReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) schedule(c) else FakeCall.ring(c, briefing(c))
    }
    companion object {
        fun schedule(c: Context) {
            val am = c.getSystemService(AlarmManager::class.java)
            val pi = PendingIntent.getBroadcast(c, 1, Intent(c, BriefingReceiver::class.java), PendingIntent.FLAG_IMMUTABLE)
            am.cancel(pi); val m = Prefs.interval(c); if (m <= 0) return
            am.setInexactRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + m * 60_000L, m * 60_000L, pi)
        }
        fun briefing(c: Context): String {
            val since = Prefs.lastBriefed(c); val new = Notifs.all(c).filter { it.time > since }
            val items = runBlocking(Dispatchers.IO) { Db.get(c).dao().all().first() }
            val tasks = items.filter { it.type == "task" && it.status != "done" }.take(3)
            val ev = items.firstOrNull { it.type == "event" && it.status == "confirmed" && (it.whenMs ?: 0) > System.currentTimeMillis() }
            Prefs.setBriefed(c, System.currentTimeMillis())
            val parts = mutableListOf(Prefs.get(c, "greet"), Prefs.get(c, "brief_intro"))
            if (new.isEmpty()) parts += Prefs.get(c, "nothing")
            else parts += "You have ${new.size} new notifications: " + new.groupBy { it.app }.entries.sortedByDescending { it.value.size }.take(4).joinToString(", ") { "${it.value.size} from ${it.key}" } + "."
            if (tasks.isNotEmpty()) parts += "Pending tasks: " + tasks.joinToString(", ") { it.title } + "."
            ev?.let { parts += "Next event: ${it.title}." }
            parts += Prefs.get(c, "goodbye"); return parts.joinToString(" ")
        }
        fun readout(c: Context): String = Notifs.all(c).take(5).joinToString(" ") { "${it.app}: ${it.title}. ${it.text}." }.ifEmpty { Prefs.get(c, "nothing") }
    }
}
