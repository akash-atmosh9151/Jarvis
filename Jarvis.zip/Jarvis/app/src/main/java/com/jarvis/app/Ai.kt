package com.jarvis.app
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Optional cloud AI (Gemini or Claude) using the user's own API key. Without a key, simple rules are used. */
object Ai {
    fun enabled(c: Context) = Prefs.aiKey(c).isNotBlank()
    fun ask(c: Context, prompt: String): String? {
        val key = Prefs.aiKey(c); val claude = Prefs.aiProvider(c) == "claude"; val model = Prefs.aiModel(c)
        return runCatching {
            val url = if (claude) "https://api.anthropic.com/v1/messages"
                else "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key"
            val body = if (claude) JSONObject().put("model", model).put("max_tokens", 800)
                .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
            else JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            val con = URL(url).openConnection() as HttpURLConnection
            con.requestMethod = "POST"; con.doOutput = true; con.connectTimeout = 15000; con.readTimeout = 40000
            con.setRequestProperty("content-type", "application/json")
            if (claude) { con.setRequestProperty("x-api-key", key); con.setRequestProperty("anthropic-version", "2023-06-01") }
            con.outputStream.use { it.write(body.toString().toByteArray()) }
            val ok = con.responseCode in 200..299
            val txt = (if (ok) con.inputStream else con.errorStream).bufferedReader().readText()
            if (!ok) { Status.add("AI error ${con.responseCode}: ${txt.take(80)}"); return@runCatching null }
            val j = JSONObject(txt)
            if (claude) j.getJSONArray("content").getJSONObject(0).getString("text")
            else j.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        }.onFailure { Status.add("AI failed: ${it.message}") }.getOrNull()
    }
}
