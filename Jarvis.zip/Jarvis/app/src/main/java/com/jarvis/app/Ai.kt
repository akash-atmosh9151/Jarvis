package com.jarvis.app
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Optional cloud AI (Gemini or Claude) using the user's own API key. Retries busy errors. */
object Ai {
    fun enabled(c: Context) = Prefs.aiKey(c).isNotBlank()
    fun ask(c: Context, prompt: String): String? = chat(c, listOf("user" to prompt), null)

    /** msgs = list of ("user" | "assistant") to text, oldest first. */
    fun chat(c: Context, msgs: List<Pair<String, String>>, system: String?): String? {
        val claude = Prefs.aiProvider(c) == "claude"; val base = Prefs.aiModel(c)
        val tries = if (claude) listOf(base, base, base) else listOf(base, "gemini-flash-lite-latest", base)
        tries.forEachIndexed { i, m ->
            val (code, text) = once(c, msgs, system, m, claude)
            if (code in 200..299) return text
            Status.add("AI error $code (try ${i + 1}/3): ${text?.take(60)}")
            if (code != -1 && code !in listOf(429, 500, 502, 503, 529)) return null
            if (i < tries.size - 1) Thread.sleep(3000L * (i + 1))
        }
        return null
    }

    private fun once(c: Context, msgs: List<Pair<String, String>>, system: String?, model: String, claude: Boolean): Pair<Int, String?> = runCatching {
        val key = Prefs.aiKey(c)
        val url = if (claude) "https://api.anthropic.com/v1/messages"
            else "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key"
        val body = JSONObject()
        if (claude) {
            body.put("model", model).put("max_tokens", 800)
            if (system != null) body.put("system", system)
            body.put("messages", JSONArray(msgs.map { JSONObject().put("role", it.first).put("content", it.second) }))
        } else {
            if (system != null) body.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            body.put("contents", JSONArray(msgs.map { JSONObject().put("role", if (it.first == "user") "user" else "model")
                .put("parts", JSONArray().put(JSONObject().put("text", it.second))) }))
        }
        val con = URL(url).openConnection() as HttpURLConnection
        con.requestMethod = "POST"; con.doOutput = true; con.connectTimeout = 15000; con.readTimeout = 40000
        con.setRequestProperty("content-type", "application/json")
        if (claude) { con.setRequestProperty("x-api-key", key); con.setRequestProperty("anthropic-version", "2023-06-01") }
        con.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = con.responseCode
        val txt = (if (code in 200..299) con.inputStream else con.errorStream).bufferedReader().readText()
        if (code !in 200..299) return@runCatching code to txt
        val j = JSONObject(txt)
        code to if (claude) j.getJSONArray("content").getJSONObject(0).getString("text")
            else j.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    }.getOrElse { -1 to it.message }
}
