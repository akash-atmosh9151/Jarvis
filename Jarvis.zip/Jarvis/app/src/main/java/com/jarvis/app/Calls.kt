package com.jarvis.app
import android.telecom.Call
import kotlinx.coroutines.flow.MutableStateFlow

const val ANSWER_DELAY_MS = 8_000L // rings this long, then Jarvis picks up (if On duty)
object Calls {
    @Volatile var current: Call? = null
    @Volatile var service: JarvisInCallService? = null
    val state = MutableStateFlow(Call.STATE_DISCONNECTED)
}
