package com.jarvis.app
import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import androidx.glance.appwidget.updateAll
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZonedDateTime

/** Conversation with Jarvis: answers questions, knows your tasks/events/notes/alerts, and can add items on request. */
object Chat {
    val log = mutableStateListOf(false to "Ask me anything, or tell me to add a note, task or event.") // true = you
    private val history = mutableListOf<Pair<String, String>>()

    private fun system(c: Context): String {
        val items = runBlocking(Dispatchers.IO) { Db.get(c).dao().all().first() }
        val fmt = java.text.SimpleDateFormat("EEE d MMM HH:mm", java.util.Locale.getDefault())
        val tasks = items.filter { it.type == "task" && it.status != "done" }.take(6).joinToString("; ") { it.title }
        val events = items.filter { it.type == "event" && (it.whenMs ?: 0) > System.currentTimeMillis() }.take(4)
            .joinToString("; ") { "${it.title} (${fmt.format(java.util.Date(it.whenMs ?: 0))}, ${it.status})" }
        val notes = items.filter { it.type == "note" }.take(5).joinToString("; ") { it.title }
        val news = Notifs.all(c).filter { it.p >= 2 }.take(5).joinToString("; ") { it.sum }
        return """You are JARVIS, the user's personal AI assistant on their phone: capable, concise, a little witty. Match the tone of this greeting the user chose: "${Prefs.get(c, "greet")}".
Reply in 1-3 short sentences because your reply is spoken aloud. No markdown, no emojis, no lists.
Now: ${ZonedDateTime.now()}. Pending tasks: [$tasks]. Upcoming events: [$events]. Recent notes: [$notes]. Important notifications: [$news].
When the user asks you to add a note, task, reminder or event, append one line per item at the very end: ACTION: {"type":"note|task|event","title":"short title","when":"yyyy-MM-ddTHH:mm in local time, or null"}
Events stay pending until the user confirms them in the app, so say so. Never mention the ACTION line."""
    }

    suspend fun reply(c: Context, text: String): String {
        if (!Ai.enabled(c)) return "I need an AI key in Settings before I can answer questions."
        history += "user" to text
        while (history.size > 16) { history.removeAt(0); if (history[0].first != "user") history.removeAt(0) }
        val out = Ai.chat(c, history.toList(), system(c))
        if (out == null) { history.removeAt(history.lastIndex); return "I couldn't reach the AI just now. Please try again in a moment." }
        val dao = Db.get(c).dao()
        val acts = Regex("ACTION:\\s*(\\{.*\\})").findAll(out).toList()
        acts.forEach { m -> runCatching {
            val o = JSONObject(m.groupValues[1]); val w = o.optString("when", "null")
            val ms = if (w == "null" || w.isBlank()) null else LocalDateTime.parse(w).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
            dao.add(Item(type = o.getString("type"), title = o.getString("title"), whenMs = ms)) } }
        if (acts.isNotEmpty()) runCatching { JarvisWidget().updateAll(c) }
        val spoken = out.replace(Regex("ACTION:.*"), "").trim()
        history += "assistant" to spoken
        return spoken
    }
}
