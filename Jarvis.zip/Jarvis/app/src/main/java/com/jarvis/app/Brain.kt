package com.jarvis.app
import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import org.json.JSONArray
import java.io.File

/** Turns raw speech/text into notes, tasks and events. Local Gemma if model file exists, else keyword fallback. */
class Brain(private val ctx: Context) {
    private val model = File(ctx.getExternalFilesDir(null), "model.task") // drop a Gemma .task file here
    private val llm by lazy {
        if (!model.exists()) null else LlmInference.createFromOptions(ctx,
            LlmInference.LlmInferenceOptions.builder().setModelPath(model.path).setMaxTokens(512).build())
    }
    private val prompt = """Classify the text into items. Reply ONLY with a JSON array of
{"type":"note|task|event","title":"...","when":"epoch-millis or null"}. Now (ms): %d. Text: %s"""

    fun classify(text: String): List<Item> {
        val raw = runCatching { llm?.generateResponse(prompt.format(System.currentTimeMillis(), text)) }.getOrNull()
        return runCatching {
            val a = JSONArray(raw!!.substring(raw.indexOf('['), raw.lastIndexOf(']') + 1))
            (0 until a.length()).map { val o = a.getJSONObject(it)
                Item(type = o.getString("type"), title = o.getString("title"),
                    whenMs = o.optString("when").toLongOrNull()) }
        }.getOrElse { fallback(text) }
    }
    private fun fallback(t: String): List<Item> {
        val l = t.lowercase()
        val type = when {
            Regex("meeting|appointment|tomorrow|at \\d").containsMatchIn(l) -> "event"
            Regex("remind|todo|need to|buy|call|submit").containsMatchIn(l) -> "task"
            else -> "note" }
        return listOf(Item(type = type, title = t))
    }
}
