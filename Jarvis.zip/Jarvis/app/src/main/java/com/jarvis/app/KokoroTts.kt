package com.jarvis.app
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.k2fsa.sherpa.onnx.*
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Kokoro-82M on-device via sherpa-onnx. Voice 9 = bm_george (British male), 10 = bm_lewis. */
class KokoroTts(private val ctx: Context) {
    companion object {
        const val MODEL_URL = "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/kokoro-en-v0_19.tar.bz2"
        fun dir(c: Context) = File(c.getExternalFilesDir(null), "kokoro-en-v0_19")
        fun ready(c: Context) = File(dir(c), ".ready").exists()
        @Volatile private var inst: OfflineTts? = null
        @Synchronized fun engine(c: Context): OfflineTts = inst ?: run {
            val d = dir(c).path
            OfflineTts(config = OfflineTtsConfig(model = OfflineTtsModelConfig(
                kokoro = OfflineTtsKokoroModelConfig(model = "$d/model.onnx", voices = "$d/voices.bin", tokens = "$d/tokens.txt", dataDir = "$d/espeak-ng-data"),
                numThreads = 4))).also { inst = it } }
        fun download(c: Context) {
            val base = c.getExternalFilesDir(null)!!; val tmp = File(base, "kokoro.tar.bz2"); var fails = 0; var logged = 0L
            while (true) {
                try {
                    val con = URL(MODEL_URL).openConnection() as HttpURLConnection
                    if (tmp.exists()) con.setRequestProperty("Range", "bytes=${tmp.length()}-")
                    con.connectTimeout = 20000; con.readTimeout = 30000; con.connect()
                    if (con.responseCode == 416) break // already complete
                    java.io.FileOutputStream(tmp, con.responseCode == 206).use { o -> con.inputStream.use { i ->
                        val buf = ByteArray(65536); var n: Int
                        while (i.read(buf).also { n = it } > 0) { o.write(buf, 0, n)
                            if (tmp.length() - logged > 25_000_000) { logged = tmp.length(); Status.add("Voice download: ${logged / 1_000_000} MB") } } } }
                    break
                } catch (e: IOException) {
                    if (++fails > 40) throw e
                    Status.add("Connection dropped, resuming at ${tmp.length() / 1_000_000} MB"); Thread.sleep(2000)
                }
            }
            Status.add("Unpacking voice...")
            TarArchiveInputStream(BZip2CompressorInputStream(tmp.inputStream().buffered())).use { tar ->
                while (true) {
                    val e = tar.nextTarEntry ?: break; val f = File(base, e.name)
                    if (!f.canonicalPath.startsWith(base.canonicalPath)) continue
                    if (e.isDirectory) f.mkdirs() else { f.parentFile?.mkdirs(); f.outputStream().use { o -> tar.copyTo(o) } }
                }
            }
            tmp.delete(); File(dir(c), ".ready").writeText("ok")
        }
    }
    private val tts get() = engine(ctx)
    private val exec = java.util.concurrent.Executors.newSingleThreadExecutor()
    @Volatile private var gen = 0
    @Volatile private var track: AudioTrack? = null
    fun warmUp() { exec.execute { Status.add("Voice loading..."); runCatching { tts }.onSuccess { Status.add("Voice ready") }.onFailure { Status.add("Voice load failed: ${it.message}") } } }
    fun speak(text: String, sid: Int = 9, onDone: () -> Unit) {
        runCatching { track?.stop() }; val my = ++gen
        exec.execute {
            runCatching {
                for (s in text.split(Regex("(?<=[.!?])\\s+")).filter { it.isNotBlank() }) {
                    if (my != gen) return@execute
                    val a = tts.generate(text = s, sid = sid, speed = 1.0f)
                    if (my != gen) return@execute
                    play(a, my)
                }
            }.onFailure { Status.add("Kokoro error: ${it.message}") }
            if (my == gen) onDone()
        }
    }
    private fun play(a: GeneratedAudio, my: Int) {
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_FLOAT).setSampleRate(a.sampleRate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(a.samples.size * 4).setTransferMode(AudioTrack.MODE_STATIC).build()
        track = t; t.write(a.samples, 0, a.samples.size, AudioTrack.WRITE_BLOCKING); t.play()
        val end = System.currentTimeMillis() + a.samples.size * 1000L / a.sampleRate + 150
        while (System.currentTimeMillis() < end && my == gen) Thread.sleep(40)
        runCatching { t.stop() }; t.release()
    }
    fun stop() { gen++; runCatching { track?.stop() } }
}
