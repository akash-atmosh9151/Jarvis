package com.jarvis.app
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.k2fsa.sherpa.onnx.*
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import java.io.File
import java.net.URL

/** Kokoro-82M on-device via sherpa-onnx. Voice 9 = bm_george (British male), 10 = bm_lewis. */
class KokoroTts(private val ctx: Context) {
    companion object {
        const val MODEL_URL = "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/kokoro-en-v0_19.tar.bz2"
        fun dir(c: Context) = File(c.getExternalFilesDir(null), "kokoro-en-v0_19")
        fun ready(c: Context) = File(dir(c), ".ready").exists()
        fun download(c: Context) {
            val base = c.getExternalFilesDir(null)!!; var n = 0L
            TarArchiveInputStream(BZip2CompressorInputStream(URL(MODEL_URL).openStream().buffered())).use { tar ->
                while (true) {
                    val e = tar.nextTarEntry ?: break
                    val f = File(base, e.name)
                    if (!f.canonicalPath.startsWith(base.canonicalPath)) continue
                    if (e.isDirectory) f.mkdirs() else {
                        f.parentFile?.mkdirs(); f.outputStream().use { o -> n += tar.copyTo(o) }
                        Status.add("Voice download: ${n / 1_000_000} MB") }
                }
            }
            File(dir(c), ".ready").writeText("ok")
        }
    }
    private val tts by lazy {
        val d = dir(ctx).path
        OfflineTts(config = OfflineTtsConfig(model = OfflineTtsModelConfig(
            kokoro = OfflineTtsKokoroModelConfig(model = "$d/model.onnx", voices = "$d/voices.bin", tokens = "$d/tokens.txt", dataDir = "$d/espeak-ng-data"),
            numThreads = 4)))
    }
    @Volatile private var track: AudioTrack? = null
    fun speak(text: String, sid: Int = 9, onDone: () -> Unit) { Thread {
        runCatching {
            val a = tts.generate(text = text, sid = sid, speed = 1.0f)
            val t = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_FLOAT).setSampleRate(a.sampleRate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(a.samples.size * 4).setTransferMode(AudioTrack.MODE_STATIC).build()
            track = t; t.write(a.samples, 0, a.samples.size, AudioTrack.WRITE_BLOCKING); t.play()
            Thread.sleep(a.samples.size * 1000L / a.sampleRate + 300); t.release()
        }.onFailure { Status.add("Kokoro error: ${it.message}") }
        onDone()
    }.start() }
    fun stop() { runCatching { track?.stop() } }
}
