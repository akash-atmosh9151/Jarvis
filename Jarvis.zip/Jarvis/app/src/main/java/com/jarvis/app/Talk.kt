package com.jarvis.app
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*

/** A one-to-one voice call with Jarvis: he greets you, you talk, he answers, repeat. */
class TalkActivity : ComponentActivity() {
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var voice: Voice
    private var state by mutableStateOf("calling")
    private var line by mutableStateOf("")
    private var muted by mutableStateOf(false)
    private var secs by mutableStateOf(0)
    private var fails = 0
    private var over = false

    override fun onCreate(s: Bundle?) {
        super.onCreate(s); window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        voice = Voice(this)
        setContent {
            MaterialTheme(darkColorScheme(primary = Gold, background = Color(0xFF05080F), surface = Color(0xFF05080F))) {
                Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF05080F), Color(0xFF0B1628)))).padding(24.dp),
                    Arrangement.SpaceBetween, Alignment.CenterHorizontally) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(top = 48.dp)) {
                        Text("J.A.R.V.I.S.", fontSize = 28.sp, letterSpacing = 8.sp, color = Gold, fontFamily = FontFamily.Monospace)
                        Text(if (state == "calling") "CALLING..." else "%02d:%02d  %s".format(secs / 60, secs % 60, if (muted) "MUTED" else state.uppercase()),
                            fontSize = 13.sp, letterSpacing = 3.sp, color = GoldL.copy(alpha = 0.8f), fontFamily = FontFamily.Monospace)
                    }
                    JarvisOrb(state == "speaking" || state == "thinking", Modifier.size(300.dp).clickable { if (state == "speaking") { voice.stop(); listen() } })
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(bottom = 40.dp)) {
                        Text(line, textAlign = TextAlign.Center, color = GoldL, fontFamily = FontFamily.Monospace, fontSize = 14.sp, maxLines = 5,
                            modifier = Modifier.padding(bottom = 20.dp).heightIn(min = 90.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                            OutlinedButton({ muted = !muted; if (muted) voice.cancelListen() else if (state == "muted" || state == "listening") listen() },
                                Modifier.height(56.dp).width(120.dp)) { Text(if (muted) "Unmute" else "Mute", color = Gold) }
                            Button({ hangUp(null) }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB71C1C), contentColor = Color.White),
                                shape = RoundedCornerShape(50), modifier = Modifier.height(56.dp).width(120.dp)) { Text("End") }
                        }
                    }
                }
            }
        }
        scope.launch { while (!over) { delay(1000); secs++ } }
        scope.launch {
            delay(1500); if (over) return@launch
            state = "speaking"; line = Prefs.get(this@TalkActivity, "greet")
            voice.speak(line) { listen() }
        }
    }

    private fun listen() {
        if (over) return
        if (muted) { state = "muted"; return }
        state = "listening"
        voice.listen(onFail = {
            if (++fails >= 4) hangUp("Still there? I'll end the call. Ring me any time.")
            else window.decorView.postDelayed({ listen() }, 600)
        }) { text ->
            fails = 0; line = text
            if (Regex("\\b(bye|goodbye|hang up|end call)\\b", RegexOption.IGNORE_CASE).containsMatchIn(text)) hangUp("Goodbye.")
            else {
                state = "thinking"; Chat.log.add(true to text)
                scope.launch {
                    val r = withContext(Dispatchers.IO) { Chat.reply(this@TalkActivity, text) }
                    if (!over) { Chat.log.add(false to r); line = r; state = "speaking"; voice.speak(r) { listen() } }
                }
            }
        }
    }

    private fun hangUp(msg: String?) {
        over = true
        if (msg == null) { voice.stop(); finish() }
        else { state = "ended"; line = msg; voice.speak(msg) { finish() } }
    }
    override fun onDestroy() { over = true; scope.cancel(); voice.shutdown(); super.onDestroy() }
}
