package com.jarvis.app
import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.glance.appwidget.updateAll
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.WRITE_CALENDAR,
            Manifest.permission.READ_CALENDAR, Manifest.permission.POST_NOTIFICATIONS), 1)
        val dao = Db.get(this).dao(); val brain = Brain(this); val voice = Voice(this)
        setContent {
            MaterialTheme(darkColorScheme(primary = Color(0xFFFFB300), background = Color(0xFF0B0F1A), surface = Color(0xFF141A2A))) {
                val items by dao.all().collectAsState(emptyList()); val scope = rememberCoroutineScope()
                var text by remember { mutableStateOf("") }
                fun submit(t: String) = scope.launch {
                    val r = withContext(Dispatchers.IO) { brain.classify(t).onEach { dao.add(it) } }
                    voice.speak("Noted. " + r.joinToString { "${it.type}: ${it.title}" })
                    JarvisWidget().updateAll(this@MainActivity)
                    WaService.send("Jarvis: " + r.joinToString { "${it.type} - ${it.title}" })
                }
                Surface(Modifier.fillMaxSize()) { Column(Modifier.padding(16.dp).statusBarsPadding()) {
                    Text("J.A.R.V.I.S.", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
                    Row(Modifier.padding(vertical = 8.dp)) {
                        OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("Tell Jarvis...") })
                        Button({ if (text.isNotBlank()) { submit(text); text = "" } }, Modifier.padding(start = 8.dp)) { Text("Send") }
                    }
                    Row { Button({ voice.listen { submit(it) } }) { Text("🎤 Speak") }
                        TextButton({ startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }) { Text("Enable WhatsApp link") } }
                    LazyColumn { items(items) { i -> Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${i.type.uppercase()}  ${i.title}", Modifier.weight(1f))
                            if (i.type == "event" && i.status == "new") TextButton({ scope.launch {
                                if (addToCalendar(this@MainActivity, i)) withContext(Dispatchers.IO) { dao.update(i.copy(status = "confirmed")) } } }) { Text("Confirm") }
                            else if (i.type == "task" && i.status != "done") TextButton({ scope.launch(Dispatchers.IO) { dao.update(i.copy(status = "done")); } }) { Text("Done") }
                        } } } }
                } }
            }
        }
    }
}
