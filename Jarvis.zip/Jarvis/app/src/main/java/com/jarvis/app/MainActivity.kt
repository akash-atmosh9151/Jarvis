package com.jarvis.app
import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.WRITE_CALENDAR,
            Manifest.permission.READ_CALENDAR, Manifest.permission.POST_NOTIFICATIONS), 1)
        val dao = Db.get(this).dao(); val brain = Brain(this); val voice = Voice(this)
        BriefingReceiver.schedule(this)
        setContent {
            MaterialTheme(darkColorScheme(primary = Color(0xFFFFB300), background = Color(0xFF0B0F1A), surface = Color(0xFF141A2A))) {
                var tab by remember { mutableStateOf(0) }
                Surface(Modifier.fillMaxSize()) { Column(Modifier.statusBarsPadding()) {
                    Text("J.A.R.V.I.S.", Modifier.padding(16.dp), style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
                    TabRow(tab) { listOf("Home", "Alerts", "Settings").forEachIndexed { i, t -> Tab(tab == i, { tab = i }, text = { Text(t) }) } }
                    when (tab) { 0 -> Home(dao, brain, voice); 1 -> Alerts(); else -> SettingsTab(voice) }
                } }
            }
        }
    }
}
