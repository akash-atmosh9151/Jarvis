package com.jarvis.app
import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject

/** Editable settings + the default responses Jarvis uses. */
object Prefs {
    val defaults = linkedMapOf(
        "greet" to "Good evening, sir. Jarvis here.",
        "brief_intro" to "Here is your briefing.",
        "important" to "Sir, important alert from %app%. %title%. %text%",
        "nothing" to "Nothing new, sir.",
        "goodbye" to "That is all, sir. Jarvis out.",
        "noted" to "Noted, sir.")
    val labels = mapOf("greet" to "Call greeting", "brief_intro" to "Briefing intro",
        "important" to "Important alert (use %app% %title% %text%)", "nothing" to "When nothing is new",
        "goodbye" to "Goodbye line", "noted" to "After saving a note")
    private fun p(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    fun get(c: Context, k: String): String = p(c).getString("r_$k", null) ?: defaults[k]!!
    fun set(c: Context, k: String, v: String) = p(c).edit().putString("r_$k", v).apply()
    fun reset(c: Context) { val e = p(c).edit(); defaults.keys.forEach { e.remove("r_$it") }; e.apply() }
    fun keywords(c: Context): String = p(c).getString("kw", "") ?: ""
    fun setKeywords(c: Context, s: String) = p(c).edit().putString("kw", s).apply()
    fun importantApps(c: Context): Set<String> = p(c).getStringSet("apps", emptySet())!!.toSet()
    fun toggleApp(c: Context, pkg: String) {
        val s = importantApps(c).toMutableSet(); if (!s.add(pkg)) s.remove(pkg); p(c).edit().putStringSet("apps", s).apply() }
    fun interval(c: Context): Int = p(c).getInt("interval", 0) // minutes, 0 = off
    fun setInterval(c: Context, m: Int) = p(c).edit().putInt("interval", m).apply()
    fun lastBriefed(c: Context): Long = p(c).getLong("briefed", 0)
    fun setBriefed(c: Context, t: Long) = p(c).edit().putLong("briefed", t).apply()
    fun lastUrgent(c: Context): Long = p(c).getLong("urgent", 0)
    fun setUrgent(c: Context, t: Long) = p(c).edit().putLong("urgent", t).apply()
    fun aiKey(c: Context): String = p(c).getString("ai_key", "") ?: ""
    fun setAiKey(c: Context, s: String) = p(c).edit().putString("ai_key", s.trim()).apply()
    fun aiProvider(c: Context): String = p(c).getString("ai_prov", "gemini") ?: "gemini"
    fun setAiProvider(c: Context, s: String) = p(c).edit().putString("ai_prov", s).apply()
    fun aiModel(c: Context): String { val pr = aiProvider(c)
        return p(c).getString("ai_model_$pr", null)?.takeIf { it.isNotBlank() } ?: if (pr == "claude") "claude-haiku-5-5" else "gemini-flash-latest" }
    fun setAiModel(c: Context, s: String) = p(c).edit().putString("ai_model_${aiProvider(c)}", s.trim()).apply()
}

data class Notif(val pkg: String, val app: String, val title: String, val text: String, val time: Long, val p: Int = -1, val sum: String = "")
/** Last 100 notifications, stored only on this phone. */
object Notifs {
    val tick = MutableStateFlow(0)
    private fun p(c: Context) = c.getSharedPreferences("notifs", Context.MODE_PRIVATE)
    @Synchronized fun rate(c: Context, r: Map<Long, Pair<Int, String>>) {
        val a = JSONArray(p(c).getString("l", "[]"))
        for (i in 0 until a.length()) { val o = a.getJSONObject(i); r[o.getLong("d")]?.let { o.put("q", it.first).put("m", it.second) } }
        p(c).edit().putString("l", a.toString()).apply(); tick.value++
    }
    @Synchronized fun add(c: Context, n: Notif) {
        val a = JSONArray(p(c).getString("l", "[]"))
        a.put(JSONObject().put("p", n.pkg).put("a", n.app).put("t", n.title).put("x", n.text).put("d", n.time).put("q", n.p).put("m", n.sum))
        val out = JSONArray(); for (i in maxOf(0, a.length() - 100) until a.length()) out.put(a.get(i))
        p(c).edit().putString("l", out.toString()).apply(); tick.value++
    }
    fun all(c: Context): List<Notif> {
        val a = JSONArray(p(c).getString("l", "[]"))
        return (0 until a.length()).map { val o = a.getJSONObject(it)
            Notif(o.getString("p"), o.getString("a"), o.getString("t"), o.getString("x"), o.getLong("d"), o.optInt("q", -1), o.optString("m", "")) }.reversed()
    }
}
