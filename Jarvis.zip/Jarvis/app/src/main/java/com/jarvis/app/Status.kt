package com.jarvis.app
import kotlinx.coroutines.flow.MutableStateFlow
object Status { val log = MutableStateFlow<List<String>>(emptyList()); fun add(s: String) { log.value = (log.value + s).takeLast(30) } }
